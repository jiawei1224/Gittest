package bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "car")
public class Car {
	@Id
	@GeneratedValue(generator = "native")
	@GenericGenerator(name = "native", strategy = "identity")
	@Column(name = "id")
	private int id;
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "rid")
	private Room room;
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name = "uid")
	private User user;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
}
