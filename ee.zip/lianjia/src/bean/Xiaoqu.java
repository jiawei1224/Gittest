package bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "xiaoqu")
public class Xiaoqu {
	@Id
	@GeneratedValue(generator = "native")
	@GenericGenerator(name = "native", strategy = "identity")
	@Column(name = "id")
	private int id;
	@Column(name = "name")
	private String name;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "ddid")
	private Didian didian;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Didian getDidian() {
		return didian;
	}
	public void setDidian(Didian didian) {
		this.didian = didian;
	}
	
}
