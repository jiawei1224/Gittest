package bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "room")
public class Room {
	@Id
	@GeneratedValue(generator = "native")
	@GenericGenerator(name = "native", strategy = "identity")
	@Column(name = "id")
	private int id;
	@Column(name = "picture")
	private String picture;
	@Column(name = "mianji")
	private String mianji;
	@Column(name = "price")
	private String price;
	@Column(name = "weizhi")
	private String weizhi;
	@Column(name = "huxing")
	private String huxing;
	@Column(name = "louceng")
	private String louceng;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "xiaoquid")
	private Xiaoqu xiaoqu;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "typeid")
	private Type type;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMianji() {
		return mianji;
	}

	public void setMianji(String mianji) {
		this.mianji = mianji;
	}


	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getWeizhi() {
		return weizhi;
	}

	public void setWeizhi(String weizhi) {
		this.weizhi = weizhi;
	}

	public String getHuxing() {
		return huxing;
	}

	public void setHuxing(String huxing) {
		this.huxing = huxing;
	}

	public String getLouceng() {
		return louceng;
	}

	public void setLouceng(String louceng) {
		this.louceng = louceng;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public Xiaoqu getXiaoqu() {
		return xiaoqu;
	}

	public void setXiaoqu(Xiaoqu xiaoqu) {
		this.xiaoqu = xiaoqu;
	}

	
	

}
