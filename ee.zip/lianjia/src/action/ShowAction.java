package action;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import com.opensymphony.xwork2.ActionContext;

@ParentPackage("struts-default")
@Namespace(value="/")
public class ShowAction {
	@Action(value = "show", results = { @Result(name = "show", location = "/WEB-INF/jsp/index.jsp") })	
	public String show(){
		
		return "show";
	}
	
	@Action(value = "zhuce", results = { @Result(name = "zhuce", location = "/WEB-INF/jsp/zhuce.jsp") })	
	public String zhuce(){		
		return "zhuce";
	}
	
	@Action(value = "tuichu", results = { @Result(name = "tuichu", location = "/WEB-INF/jsp/login.jsp") })	
	public String tuichu(){	
		Map session = ActionContext.getContext().getSession();
		session.clear();
		return "tuichu";
	}
	
	
}
