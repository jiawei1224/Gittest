package action;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import service.UserService;
import bean.User;


@ParentPackage("struts-default")
@Namespace(value="/")
public class LoginAction {
	@Resource
	UserService userService;
	
	private String name;
	private String password;

	@Action(value = "login", results = { @Result(name = "login", location = "/WEB-INF/jsp/login.jsp") })	
	public String login(){		
		return "login";
	}
	@Action(value="user",results={@Result(name="success",location="/WEB-INF/jsp/index.jsp")
	,@Result(name="fail",location="/WEB-INF/jsp/login.jsp")})
	public String user(){
		User user=userService.searchU(name,password);
		HttpSession session = ServletActionContext.getRequest().getSession();
		session.setAttribute("user",user);
		if(user!=null){		
			return "success"; 
		}else{
			return "fail";
		}		
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
