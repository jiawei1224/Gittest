package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;

import service.SearchService;
import bean.Car;
import bean.Room;
import bean.User;

@ParentPackage("struts-default")
@Namespace(value="/")
public class SearchAction {
	@Resource
	SearchService searchService;

	private String neirong;
	private List<Room> rooms;
	private int rid;
	private Car car;
	private List<Car> shoucang;
	private List<Car> list;

	@Action(value = "ershoufang", results = { @Result(name = "ershoufang", location = "/WEB-INF/jsp/liebiao.jsp") })	
	public String ershoufang(){	
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
		
		try {
			neirong=new String(neirong.trim().getBytes("ISO-8859-1"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(user!=null){
		int uid=user.getId();
		if(neirong!=null){
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.ershoufang(neirong);
		}else{
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.ershoufangA();
		}
		}else{
			if(neirong!=null){
				rooms=searchService.ershoufang(neirong);
			}else{
				rooms=searchService.ershoufangA();
			}
		}
		return "ershoufang";
	}
	@Action(value = "loupan", results = { @Result(name = "loupan", location = "/WEB-INF/jsp/liebiao.jsp") })	
	public String loupan(){		
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
		int uid=user.getId();
		try {
			neirong=new String(neirong.trim().getBytes("ISO-8859-1"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(neirong!=null){
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.loupan(neirong);
		}else{
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.loupanA();
		}
		return "loupan";
	}
	@Action(value = "zufang", results = { @Result(name = "zufang", location = "/WEB-INF/jsp/liebiao.jsp") })	
	public String zufang(){	
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
		int uid=user.getId();
		try {
			neirong=new String(neirong.trim().getBytes("ISO-8859-1"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(neirong!=null){
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.zufang(neirong);
		}else{
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.zufangA();
		}
		return "zufang";
	}
	@Action(value = "xiaoqu", results = { @Result(name = "xiaoqu", location = "/WEB-INF/jsp/liebiao.jsp") })	
	public String xiaoqu(){		
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
		int uid=user.getId();
		try {
			neirong=new String(neirong.trim().getBytes("ISO-8859-1"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(neirong!=null&&!"".equals(neirong)){
			shoucang=searchService.searchUCar(uid);
			rooms=searchService.xiaoqu(neirong);

		}else{
			 shoucang=searchService.searchUCar(uid);
			rooms=searchService.xiaoquA();
		}
		return "xiaoqu";
	}
	
	@Action(value = "shoucang")	
	public void shoucang(){
		try {
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
			HttpServletResponse response = ServletActionContext.getResponse();		
			PrintWriter out = response.getWriter();	
		int uid=user.getId();
		Car car=new Car();
		Room room=new Room();
		room.setId(rid);
		User u=new User();
		u.setId(uid);
		car.setRoom(room);
		car.setUser(user);
		
		int i=Integer.parseInt(request.getParameter("i"));
		int result=0;
		if(i==1)
		{
			result=searchService.addshoucang(car);
			if(result>0){
				out.print(1);
				}
		}else{
			List<Car> car1=searchService.searchCar(rid,uid);
			 car=car1.get(0);
			 result=searchService.deleteCar(car);
			if(result>0){
			out.print(0);
			
		}
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Action(value = "quxiao", results = { @Result(name = "quxiao", location = "/WEB-INF/jsp/user.jsp") })	
	public String quxiao(){	
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");	
		int uid=user.getId();
		Car car=new Car();
		Room room=new Room();
		room.setId(rid);
		User u=new User();
		u.setId(uid);
		car.setRoom(room);
		car.setUser(user);	
		int result=0;
			List<Car> car1=searchService.searchCar(rid,uid);
			 car=car1.get(0);
			 result=searchService.deleteCar(car);	
			 if(result>0){
			 list=searchService.searchU(uid);
			 }
			 return "quxiao";
	}
	/*@Action(value = "quxiao")	
	public void quxiao(){
		try {
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
			HttpServletResponse response = ServletActionContext.getResponse();		
			PrintWriter out = response.getWriter();	
		int uid=user.getId();
		List<Car> car1=searchService.searchCar(rid,uid);
		Car car=car1.get(0);
		int result=searchService.deleteCar(car);
		if(result>0){
		out.print(1);
		}else{
		
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
	@Action(value = "xiangqing", results = { @Result(name = "xiangqing", location = "/WEB-INF/jsp/xiangqing.jsp") })	
	public String xiangqing(){		
			rooms=searchService.searchX(rid);
		return "xiangqing";
	}
	
	@Action(value = "zhanghu", results = { @Result(name = "zhanghu", location = "/WEB-INF/jsp/user.jsp") })	
	public String user(){		
		HttpSession session=ServletActionContext.getRequest().getSession();
		User user=(User)session.getAttribute("user");
		int uid=user.getId();
		 list=searchService.searchU(uid);
		return "zhanghu";
	}
	
		
	
	
	
	public String getNeirong() {
		return neirong;
	}
	public void setNeirong(String neirong) {
		this.neirong = neirong;
	}
	public List<Room> getRooms() {
		return rooms;
	}
	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public Car getCar() {
		return car;
	}
	public void setCar(Car car) {
		this.car = car;
	}
	public List<Car> getShoucang() {
		return shoucang;
	}
	public void setShoucang(List<Car> shoucang) {
		this.shoucang = shoucang;
	}
	public List<Car> getList() {
		return list;
	}
	public void setList(List<Car> list) {
		this.list = list;
	}
	
}
