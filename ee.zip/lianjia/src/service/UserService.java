package service;


import bean.User;

public interface UserService {

	public User searchU(String name, String password);

}
