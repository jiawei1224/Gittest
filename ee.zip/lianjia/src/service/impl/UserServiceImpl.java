package service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import bean.User;
import dao.UserDao;
import service.UserService;

@Service
public class UserServiceImpl implements UserService{
	@Resource
	UserDao userDao;

	@Override
	public User searchU(String name, String password) {
		
		return userDao.searchU(name,password);
	}
}
