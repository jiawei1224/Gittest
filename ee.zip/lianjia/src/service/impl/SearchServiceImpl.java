package service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import service.SearchService;
import bean.Car;
import bean.Room;
import dao.SearchDao;


@Service
public class SearchServiceImpl implements SearchService{
	@Resource
	SearchDao searchDao;
	
	@Override
	public List<Room> ershoufang(String neirong) {
		
		return searchDao.ershoufang(neirong);
	}

	@Override
	public List<Room> loupan(String neirong) {
		// TODO Auto-generated method stub
		return searchDao.loupan(neirong);
	}

	@Override
	public List<Room> zufang(String neirong) {
		// TODO Auto-generated method stub
		return searchDao.zufang(neirong);
	}

	@Override
	public List<Room> xiaoqu(String neirong) {
		// TODO Auto-generated method stub
		return searchDao.xiaoqu(neirong);
	}

	@Override
	public List<Room> ershoufangA() {
		// TODO Auto-generated method stub
		return searchDao.ershoufangA();
	}

	@Override
	public List<Room> loupanA() {
		// TODO Auto-generated method stub
		return searchDao.loupanA();
	}

	@Override
	public List<Room> xiaoquA() {
		// TODO Auto-generated method stub
		return searchDao.xiaoquA();
	}

	@Override
	public List<Room> zufangA() {
		// TODO Auto-generated method stub
		return searchDao.ershoufangA();
	}

	@Override
	public int addshoucang(Car car) {
		// TODO Auto-generated method stub
		return searchDao.addshoucang(car);
	}

	@Override
	public int deleteCar(Car car) {
		// TODO Auto-generated method stub
		return searchDao.deleteCar(car);
	}

	@Override
	public List<Car> searchCar(int rid, int uid) {
		// TODO Auto-generated method stub
		return searchDao.searchCar(rid,uid);
	}

	@Override
	public List<Car> searchUCar(int uid) {
		// TODO Auto-generated method stub
		return searchDao.searchUCar(uid);
	}

	@Override
	public List<Car> searchU(int uid) {
		// TODO Auto-generated method stub
		return searchDao.searchU(uid);
	}

	@Override
	public List<Room> searchX(int rid) {
		// TODO Auto-generated method stub
		return searchDao.searchX(rid);
	}
}
