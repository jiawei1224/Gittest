package dao.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import bean.Car;
import bean.Room;
import bean.User;
import dao.SearchDao;

@Repository
public class SearchDaoImpl implements SearchDao{
	@Resource
	SessionFactory sessionFactory;
	
	Session session;

	public void getSession() {
		session = sessionFactory.getCurrentSession();
	}
	
	@Override
	public List<Room> ershoufang(String neirong) {
		getSession();
		String hql = "from Room r where r.type.id="+2+" and ( r.xiaoqu.name like'%"+neirong+"%' or r.weizhi like'%"+neirong+"%')";
		System.out.println("***"+hql);
		
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	
	@Override
	public List<Room> ershoufangA() {
		getSession();
		String hql = "from Room ";	
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	
	@Override
	public List<Room> loupan(String neirong) {
		getSession();
		String hql = "from Room r where r.type.id="+1+" and (  r.xiaoqu.name like'%"+neirong+"%' or r.weizhi like'%"+neirong+"%')";
		System.out.println("***"+hql);
		
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	
	@Override
	public List<Room> loupanA() {
		getSession();
		String hql = "from Room r where r.type.id="+1;	
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	@Override
	public List<Room> zufang(String neirong) {
		getSession();
		String hql = "from Room r where r.type.id="+3+" and ( r.xiaoqu.name like'%"+neirong+"%' or r.weizhi like'%"+neirong+"%')";
		System.out.println("***"+hql);
		
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	@Override
	public List<Room> zufangA() {
		getSession();
		String hql = "from Room r where r.type.id="+3+"";
		System.out.println("***"+hql);	
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	@Override
	public List<Room> xiaoqu(String neirong) {
		getSession();
		String hql = "from Room r where r.xiaoqu.name  like'%"+neirong+"%'";
		System.out.println("***"+hql);
		
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	@Override
	public List<Room> xiaoquA() {
		getSession();
		String hql = "from Room r where r.type.id="+4+"";
		System.out.println("***"+hql);	
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
			list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		System.out.println(list.size()+"*********");
		return list;
	}

	@Override
	public int addshoucang(Car car) {
		getSession();
		 Integer ii=(Integer) session.save(car);
		return ii;
	}
	
	@Override
	public int deleteCar(Car car) {
		getSession();
		try {
		session.delete(car);
		return 1;
		} catch (Exception e) {
			// TODO: handle exception
		return 0;
		}		
	}
	@Override
	public List<Car> searchCar(int rid,int uid) {
		getSession();
		String hql = "from Car c where c.room.id="+rid+"and c.user.id="+uid;
		System.out.println("***"+hql);	
		List<Car> car=null;
		try {
			Query query = session.createQuery(hql);
		 car= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return car;
	}
	@Override
	public List<Car> searchUCar(int uid) {
		getSession();
		String hql = "from Car c where c.user.id="+uid;
		System.out.println("***"+hql);	
		List<Car> car=null;
		try {
			Query query = session.createQuery(hql);
		 car= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return car;
	}
	
	@Override
	public List<Car> searchU(int uid) {
		getSession();
		String hql = "from Car c where c.user.id="+uid;
		System.out.println("***"+hql);	
		List<Car> list=null;
		try {
			Query query = session.createQuery(hql);
		 list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
	
	
	@Override
	public List<Room> searchX(int rid) {
		getSession();
		String hql = "from Room r where r.id="+rid;
		System.out.println("***"+hql);	
		List<Room> list=null;
		try {
			Query query = session.createQuery(hql);
		 list= query.list();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
		}
		return list;
	}
}
