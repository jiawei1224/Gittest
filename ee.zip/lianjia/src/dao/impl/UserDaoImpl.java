package dao.impl;


import java.util.List;

import javax.annotation.Resource;






import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Repository;

import bean.User;
import dao.UserDao;

@Repository
public class UserDaoImpl  implements UserDao{
	@Resource
	SessionFactory sessionFactory;
	
	Session session;

	public void getSession() {
		session = sessionFactory.getCurrentSession();
	}

	@Override
	public User searchU(String name, String password) {
		getSession();
		String hql = "from User u where u.name='"+name+"' and u.password='"+password+"'";
		Query query = session.createQuery(hql);
		List<User> list= query.list();
		if(list.size()!=0){
			return list.get(0);
		}else{
			return null;
		}
		
	}


}
