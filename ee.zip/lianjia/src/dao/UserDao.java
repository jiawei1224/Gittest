package dao;



import bean.User;

public interface UserDao {
	public User searchU(String name,String password);
}
