package dao;

import java.util.List;

import bean.Car;
import bean.Room;

public interface SearchDao {
	public List<Room> ershoufang(String neirong);

	public List<Room> loupan(String neirong);

	public List<Room> zufang(String neirong);

	public List<Room> xiaoqu(String neirong);

	public List<Room> ershoufangA();

	public List<Room> loupanA();

	public List<Room> xiaoquA();

	public List<Room> zufangA();

	public int addshoucang(Car car);

	public int deleteCar(Car car);

	public List<Car> searchCar(int rid, int uid);

	public List<Car> searchUCar(int uid);

	public List<Car> searchU(int uid);

	public List<Room> searchX(int rid);

}
